#!/bin/bash
#SBATCH --job-name=preprocess_label
#SBATCH --gres=gpu:1
#SBATCH --mem=32G
#SBATCH --cpus-per-task=8
#SBATCH --time=0-24:00:00
#SBATCH --output=preprocess_label.out
#SBATCH --error=preprocess_label.err

echo "=== Slurm Array Job: $SLURM_ARRAY_TASK_ID / $SLURM_ARRAY_TASK_COUNT ==="


# 构造我们要在容器内执行的命令, 存到一个 Shell 变量 $CMD
CMD="
echo 'First, use static ffmpeg & ffprobe by overriding PATH'
export PATH=/home/dw3180/ffmpeg_static/ffmpeg-7.0.2-amd64-static:\$PATH

echo 'which ffmpeg => ' \$(which ffmpeg)
echo 'which ffprobe => ' \$(which ffprobe)
ffmpeg -version
ffprobe -version

python /sheetsage/sheetsage/train_preprocessing.py \
  --hooktheory_json_gz /sheetsage/sheetsage/Hooktheory.json.gz \
  --npz_dir /sheetsage/output \
  --out_dir /sheetsage/output \
  --test_only


  
# --part_json ${PART_JSON} 
# echo '=== Done PART=${PART} ==='
"

# 注意overlay改成 :ro 如果不需要写
#   并保证容器指令 / container path 写在同一行
singularity exec --nv \
  --overlay /scratch/dw3180/overlay-15GB-500K.ext3:ro \
  --bind /home/dw3180/sheetsage_code:/sheetsage \
  --bind /home/dw3180/sheetsage_code/.sheetsage:/sheetsage/cache \
  --bind /scratch/dw3180/sheetsage_project/output/preprocessed_output/train:/sheetsage/output \
  --bind /scratch/dw3180/sheetsage_project/audio_downloaded:/sheetsage/audio_downloaded \
  /home/dw3180/sheetsage_latest.sif \
  bash -c "$CMD"

echo '=====preprocessing complete====='
