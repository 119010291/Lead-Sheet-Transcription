import torch
import torchaudio
import numpy as np

from transformers import AutoModel, Wav2Vec2FeatureExtractor

from .base import Representation


class MertExtractor(Representation):
    def __init__(self, device=torch.device("cpu")):
        # 1) 加载 MERT 模型 + 特征提取器
        self.model_name = "m-a-p/MERT-v1-95M"
        self.device = device

        # 从 Hugging Face 加载
        self.model = AutoModel.from_pretrained(self.model_name, trust_remote_code=True).to(device)
        self.processor = Wav2Vec2FeatureExtractor.from_pretrained(self.model_name, trust_remote_code=True)

        # MERT 的默认采样率（通常是16k）
        self.target_sr = self.processor.sampling_rate

    def __call__(self, audio_path, offset=0.0, duration=None):
        """
        :param audio_path: 音频文件路径 (wav)
        :param offset: 以秒为单位，起始位置
        :param duration: 以秒为单位，截取时长
        :return: (fr, feats)
          - fr: 特征帧率 (float) (每秒多少帧)
          - feats: shape [time_frames, feature_dim] 的 numpy 数组
        """
        # 2) 部分读取音频
        info = torchaudio.info(audio_path)
        sr = info.sample_rate

        frame_offset = int(offset * sr) if offset else 0
        num_frames = int(duration * sr) if duration else -1

        waveform, sr = torchaudio.load(audio_path,
                                       frame_offset=frame_offset,
                                       num_frames=num_frames)
        # 若多声道，做平均或只取第一个声道
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)

        # 3) 重采样到 target_sr
        if sr != self.target_sr:
            resampler = torchaudio.transforms.Resample(sr, self.target_sr)
            waveform = resampler(waveform)
            sr = self.target_sr

        # (channels, time) -> (time), float32
        waveform = waveform.squeeze(0).float()

        # 4) 用 processor + 模型
        inputs = self.processor(waveform, sampling_rate=sr, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in inputs.items()}  # 如果要 GPU

        with torch.no_grad():
            outputs = self.model(**inputs, output_hidden_states=True)
        
        # 取最后一层的 hidden_states: shape [batch=1, time, hidden_dim]
        hidden = outputs.hidden_states[-1].squeeze(0)
        feats = hidden.cpu().numpy()  # shape: [time_frames, feature_dim]

        # 5) 计算帧率
        real_duration_s = waveform.shape[-1] / sr  # 以秒计
        fr = feats.shape[0] / real_duration_s if real_duration_s > 0 else 0.0

        return fr, feats
