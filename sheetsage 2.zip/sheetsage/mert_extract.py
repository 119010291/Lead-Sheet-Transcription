import torch
import torchaudio
import numpy as np
import os
import gzip
import json
import logging
import librosa
from tqdm import tqdm
import subprocess
import tempfile
from transformers import AutoModel, Wav2Vec2FeatureExtractor

_JUKEBOX_CHUNK_DURATION_EDGE = 23.75

# 由于mert使用的环境不同，无法和其他embedding被一同提取

def ffmpeg_extract_segment(input_path, output_wav, start_time, end_time):
    """
    用 ffmpeg 从 input_path (可能是 .mp4/.webm/.m4a) 中
    截取区间 [start_time, end_time] 输出到 output_wav (16-bit PCM mono).
    """
    duration = end_time - start_time
    cmd = [
        "ffmpeg", "-y",  # -y: 覆盖输出
        "-ss", str(start_time),
        "-i", input_path,
        "-t", str(duration),
        "-acodec", "pcm_s16le",  # 16-bit PCM
        "-ar", "44100",          # 采样率
        "-ac", "1",              # 单声道
        output_wav
    ]
    ret = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if ret.returncode != 0:
        raise RuntimeError(f"ffmpeg extract failed: {ret.stderr.decode('utf-8', errors='ignore')}")


def _init_extractor(input_feats):
    """
    通过输入参数 input_feats（如果你需要兼容其它后端），
    这里直接返回一个基于 MERT 的提取函数 extract_mert。
    """

    # 0) 选择设备：若有可用 GPU，就用 'cuda'
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # 1) 加载 MERT 模型 & 特征提取器
    model_name = "m-a-p/MERT-v1-95M"
    model = AutoModel.from_pretrained(model_name, trust_remote_code=True)
    model.to(device)  # 将模型移动到 GPU（若 device=cuda）
    processor = Wav2Vec2FeatureExtractor.from_pretrained(model_name, trust_remote_code=True)

    target_sr = processor.sampling_rate  # MERT 通常是16k

    def extract_mert(audio_path, offset=0.0, duration=None):
        """
        读取音频文件，从 offset 秒开始，读取 duration 秒长的音频，
        然后用 MERT 提取特征，并返回 (frame_rate, feats)。
        """
        # 2) 先用 torchaudio.load() 部分读取音频
        #    torchaudio.load 的参数是 frame_offset(帧偏移)、num_frames(帧数)，而 offset/duration 是秒，因此要转换:
        #    注意：如果 offset + duration 超出音频长度，torchaudio.load 不会报错，但会返回较短音频。
        info = torchaudio.info(audio_path)
        sr = info.sample_rate

        frame_offset = int(offset * sr) if offset else 0
        num_frames = int(duration * sr) if duration else -1  # -1 表示读到文件末尾
        
        waveform, sr = torchaudio.load(
            audio_path, 
            frame_offset=frame_offset,
            num_frames=num_frames
        )
        # waveform.shape -> [channels, time]

        # 如果是立体声或多声道，可以考虑只用第一个声道，或做均值
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)  # [1, time]

        # 3) 重采样到 16k if needed
        if sr != target_sr:
            resampler = torchaudio.transforms.Resample(sr, target_sr)
            waveform = resampler(waveform)
            sr = target_sr

        # 变成1D (去掉channel维度)、float32
        waveform = waveform.squeeze(0).float()

        # 4) 用 processor 处理输入，再送入 MERT
        inputs = processor(waveform, sampling_rate=sr, return_tensors="pt")
        # 把输入张量移动到同一设备 (GPU / CPU)
        inputs = {k: v.to(device) for k, v in inputs.items()}
        with torch.no_grad():
            outputs = model(**inputs, output_hidden_states=True)

        # 这里假设取最后一层的 hidden_states
        # outputs.hidden_states 是一个tuple，每一层 shape: [batch=1, time, hidden_dim]
        # 取最后一层 -> [time, hidden_dim]
        hidden = outputs.hidden_states[-1].squeeze(0)
        feats = hidden.cpu().numpy()  # 转为 numpy array, shape: [time_frames, feature_dim]

        # 5) 计算特征帧率
        #    若读取的实际音频长度为 real_duration_s
        real_duration_s = waveform.shape[-1] / sr  # 以秒计
        #    feats.shape[0] 是特征帧数
        #    fr = 特征帧数 / 实际秒数
        #    注：对于 Wav2Vec2/BERT/hubert 系列，默认大约 50 帧/秒 (16kHz 输入)
        fr = feats.shape[0] / real_duration_s if real_duration_s > 0 else 0.0

        return fr, feats

    return extract_mert


def _extract_features(
    audio_path_or_bytes, input_feats, tertiaries_times, chunks_tertiaries, tqdm
):
    tertiary_diff_frames = np.diff(tertiaries_times) * (44100 / 128)
    if np.any(tertiary_diff_frames.astype(np.int64) == 0):
        raise ValueError("Tempo too fast for beat-informed feature resampling")
    print('step 0')
    extractor = _init_extractor(input_feats)
    print('step 0-1')
    chunks_features = []
    with tempfile.NamedTemporaryFile("wb") as f:
        if isinstance(audio_path_or_bytes, bytes):
            f.write(audio_path_or_bytes)
            f.flush()
            audio_path = f.name
        else:
            audio_path = audio_path_or_bytes
        print('in the loop now')
        for chunk_slice in tqdm(chunks_tertiaries):
            print('goes into tqdm now')
            chunk_tertiaries_times = tertiaries_times[chunk_slice]
            offset = chunk_tertiaries_times[0]
            duration = chunk_tertiaries_times[-1] - offset
            assert duration <= _JUKEBOX_CHUNK_DURATION_EDGE
            fr, feats = extractor(audio_path, offset=offset, duration=duration)
            beat_resampled = []
            for i in range(chunk_tertiaries_times.shape[0] - 1):
                s = int((chunk_tertiaries_times[i] - offset) * fr)
                e = int((chunk_tertiaries_times[i + 1] - offset) * fr)
                assert e > s
                beat_resampled.append(np.mean(feats[s:e], axis=0, keepdims=True))
            beat_resampled = np.concatenate(beat_resampled, axis=0)
            chunks_features.append(beat_resampled)

    return chunks_features


def preprocess_hooktheory(
    # part_json_path,
    hooktheory_json_gz,
    output_dir,
    input_feats="MERT", # 摆设而已，没什么用在这里
    test_only=False
):
    """
    1) 读取 Hooktheory.json.gz
    2) 筛选 TRAIN + AUDIO_AVAILABLE + MELODY + 非 TEMPO_CHANGES
    3) 对每个样本:
       - alignment => 算 start_time/end_time
       - 找到已下载的 .mp4/.webm/.m4a => ffmpeg 截取该区间 => partial.wav
       - librosa.load => beat_tracking => extract_features
       - 存 .npz
    """

    os.makedirs(output_dir, exist_ok=True)

    # ------------- (A) 读取并筛选 -------------
    with gzip.open(hooktheory_json_gz, "rt", encoding="utf-8") as f:
        dataset = json.load(f)
    # logging.info(f"Total examples in Hooktheory: {len(dataset)}")

    train_set = {
        k: v for k, v in dataset.items()
        if v["split"] == "TEST"
        and "AUDIO_AVAILABLE" in v["tags"]
        and "MELODY" in v["tags"]
        and "TEMPO_CHANGES" not in v["tags"]
    }
    logging.info(f"Filtered train set size: {len(train_set)}")

    
    downloaded_dir = "/scratch/dw3180/sheetsage_project/audio_downloaded/test"  # 容器内可访问
    possible_exts = [".mp4", ".webm", ".m4a"]       # 可能出现的后缀

    if test_only:
        
        first_uid = "BbWgMOYzolX"
        # 只构建一个 dict
        train_set = {first_uid: train_set[first_uid]}
        logging.info(f"[TEST_ONLY] Will process just this uid={first_uid}")

    # ------------- (B) 遍历样本 -------------
    # with open(part_json_path,"r", encoding="utf-8") as f:
    #     part_dict = json.load(f)
    for uid, example in tqdm(train_set.items(), desc="Preprocessing Hooktheory"):
        try:
            out_npz = os.path.join(output_dir, f"{uid}.npz")
            # 从npz文件中读取对应tertiaries_times, chunks_tertiaries
            data = np.load(out_npz, allow_pickle=True)
            if "chunks_features_mert" not in data:
                # (1) 解析 alignment
                refined = example["alignment"]["refined"]
                beats_arr = refined["beats"]
                times_arr = refined["times"]
                num_beats = example["annotations"]["num_beats"]

                # 插值得到 beat->time
                from scipy.interpolate import interp1d
                beat_to_time_fn = interp1d(
                    beats_arr,
                    times_arr,
                    kind="linear",
                    fill_value="extrapolate"
                )
                start_time = float(beat_to_time_fn(0))
                end_time   = float(beat_to_time_fn(num_beats))

                # (2) 找到已下载的音频文件: audio_{uid}.(mp4|webm|m4a)
                main_file_path = None
                for ext in possible_exts:
                    test_path = os.path.join(downloaded_dir, f"audio_{uid}{ext}")
                    if os.path.exists(test_path):
                        main_file_path = test_path
                        break

                if not main_file_path:
                    logging.error(f"No mp4/webm/m4a found for uid={uid}, skip.")
                    continue

                # (2b) 用 ffmpeg 截取 => tmp_{uid}.wav
                wav_path = f"tmp_{uid}.wav"
                ffmpeg_extract_segment(main_file_path, wav_path, start_time, end_time)

                

                chunked_tertiaries = data["chunks_tertiaries"]# object array or shape (N_chunks,T)
                tertiaries_times = data["tertiaries_times"]

                chunked_features = _extract_features(wav_path, input_feats, tertiaries_times, chunked_tertiaries, tqdm)

                new_data = dict(data)
                # new_data["chunks_labels"] = chunked_labels
                new_data["chunks_features_mert"] = np.array(chunked_features, dtype=object)
                np.savez_compressed(out_npz, **new_data)
                print(f"[offline_label_harmony] {uid} => {out_npz} 处理完成。")

                # (5) 删除临时 wav
                if os.path.exists(wav_path):
                    os.remove(wav_path)
        except Exception as e:
            logging.error(f"Failed preprocessing uid={uid}, reason={e}")
            continue

    logging.info("All done!")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Preprocess Hooktheory dataset for training (Old environment, no direct youtube download).")
    parser.add_argument("hooktheory_json_gz", type=str, help="Path to Hooktheory.json.gz")
    # parser.add_argument("--part_json", type=str, required=True,
    #     help="Path to splitted train_set_part{i}.json")
    parser.add_argument("--output_dir", type=str, help="Where to store .npz features")
    parser.add_argument("--input_feats", default="JUKEBOX", help="Input features type")
    parser.add_argument("--test_only", action="store_true", help="If set, only processes the first matching sample.")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    preprocess_hooktheory(
        args.hooktheory_json_gz,
        args.output_dir,
        input_feats=args.input_feats,
        test_only=args.test_only
    )