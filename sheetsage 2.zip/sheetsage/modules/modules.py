import math

import torch
import torch.nn as nn
import torch.nn.functional as F

# Ref: https://pytorch.org/tutorials/beginner/translation_transformer.html


def _xavier_init_params(params):
    '''这是一个辅助函数，用于对模型中维度大于1的参数进行 Xavier 均匀初始化，从而帮助模型在训练初期保持合适的梯度分布。'''
    for p in params:
        if p.dim() > 1:
            torch.nn.init.xavier_uniform_(p)


class _PositionalEmbedding(nn.Module):
    def __init__(self, emb_dim, max_len=4096):
        super().__init__()
        den = torch.exp(-torch.arange(0, emb_dim, 2) * math.log(10000) / emb_dim)
        pos = torch.arange(0, max_len).reshape(max_len, 1)
        pos_embedding = torch.zeros((max_len, emb_dim))
        pos_embedding[:, 0::2] = torch.sin(pos * den)
        pos_embedding[:, 1::2] = torch.cos(pos * den)
        pos_embedding = pos_embedding.unsqueeze(-2)
        self.register_buffer("pos_embedding", pos_embedding)

    def forward(self, emb):
        return emb + self.pos_embedding[: emb.size(0), :]


class _TokenEmbedding(nn.Module):
    '''
    用于将离散的词（或token）转换为连续的向量表示。
    内部利用 nn.Embedding 实现，同时将得到的嵌入向量乘以一个缩放因子（平方根 of emb_size），这是一种常见的技巧，用于稳定训练。
    '''
    def __init__(self, vocab_size, emb_size):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, emb_size)
        self.emb_size = emb_size

    def forward(self, tokens):
        return self.embedding(tokens.long()) * math.sqrt(self.emb_size)


class Encoder(nn.Module):
    def __init__(self, src_emb_dim):
        super().__init__()
        self.src_emb_dim = src_emb_dim

    def get_src_enc_dim(self):
        # 返回编码器输出的维度
        raise NotImplementedError()

    def _encode(self, src_emb, src_len):
        # 抽象方法，实际的编码逻辑由子类实现
        raise NotImplementedError()

    def forward(self, src_emb, src_len):
        src_max_len, batch_size, _ = src_emb.shape
        if not (
            torch.all(0 <= src_len).item() and torch.all(src_len <= src_max_len).item()
        ):
            raise ValueError("Invalid sequence lengths")
        if src_emb.shape[-1] != self.src_emb_dim:
            raise ValueError()
        return self._encode(src_emb, src_len)   # 调用_encode


class IdentityEncoder(Encoder):
    '''最简单的编码器，其作用只是将输入嵌入原样返回（即“恒等变换”）'''
    def get_src_enc_dim(self):
        return self.src_emb_dim

    def _encode(self, src_emb, src_len):
        return src_emb


class MLPEncoder(Encoder):
    '''
    实现了基于多层感知机（MLP）的编码器。
    通过一系列全连接层（Linear），每层后接 ReLU 激活函数和 dropout，从而对输入嵌入进行非线性变换，提取更高层次的特征。
    '''
    def __init__(self, src_emb_dim, hidden_layer_dims=[512], dropout_p=0.5):
        super().__init__(src_emb_dim)
        self.num_layers = len(hidden_layer_dims)
        d = self.src_emb_dim
        for i, ld in enumerate(hidden_layer_dims):
            setattr(self, f"hidden_{i}", nn.Linear(d, ld))
            d = ld
        self.output_dim = d
        self.dropout = nn.Dropout(p=dropout_p)

    def get_src_enc_dim(self):  # 返回最后一层的输出维度
        return self.output_dim

    def _encode(self, src_emb, src_len):
        src_max_len, batch_size, _ = src_emb.shape
        x = src_emb.view(src_max_len * batch_size, -1)
        for i in range(self.num_layers):
            x = getattr(self, f"hidden_{i}")(x)
            x = F.relu(x)
            x = self.dropout(x)
        x = x.view(src_max_len, batch_size, -1)
        return x


class TransformerEncoder(Encoder):
    def __init__(
        self,
        src_emb_dim,
        model_dim=512,
        num_heads=8,
        num_layers=6,
        feedforward_dim=2048,
        dropout_p=0.1,
        _legacy_for_unit_test=False,
    ):
        if src_emb_dim != model_dim:
            raise ValueError()

        if not _legacy_for_unit_test:
            super().__init__(src_emb_dim)

        transformer_layer = nn.modules.TransformerEncoderLayer(
            model_dim,
            num_heads,
            dim_feedforward=feedforward_dim,
            dropout=dropout_p,
            activation="relu",
        )
        transformer_norm = nn.modules.normalization.LayerNorm(model_dim)
        self.transformer = nn.modules.TransformerEncoder(
            transformer_layer, num_layers, norm=transformer_norm
        )

        if not _legacy_for_unit_test:
            _xavier_init_params(self.parameters())

        self.model_dim = model_dim

    def get_src_enc_dim(self):
        return self.model_dim

    def _encode(self, src_emb, src_len):
        src_max_len, batch_size, _ = src_emb.shape

        # Create sequence mask，在这里做了对padding的处理，src_len是实际长度
        seq_idxs = torch.arange(
            0, src_max_len, dtype=src_len.dtype, device=src_emb.device
        ).expand(batch_size, -1)
        # NOTE: True means *do* mask that position
        src_key_padding_mask = seq_idxs >= src_len.unsqueeze(1)

        return self.transformer(src_emb, src_key_padding_mask=src_key_padding_mask)


class Decoder(nn.Module):
    def __init__(self, src_enc_dim, tgt_emb_dim):
        super().__init__()
        self.src_enc_dim = src_enc_dim
        self.tgt_emb_dim = tgt_emb_dim

    def get_tgt_dec_dim(self):
        raise NotImplementedError()

    def _decode(self, src_enc, src_len, tgt_emb, tgt_len=None):
        raise NotImplementedError()

    def forward(self, src_enc, src_len, tgt_emb, tgt_len=None):
        if src_enc.shape[1] != tgt_emb.shape[1]:
            raise ValueError("Batch sizes must be the same")
        src_max_len, batch_size, _ = src_enc.shape
        tgt_max_len, _, _ = tgt_emb.shape
        if not (
            torch.all(0 <= src_len).item() and torch.all(src_len <= src_max_len).item()
        ):
            raise ValueError("Invalid sequence lengths")
        if tgt_len is not None:
            if not (
                torch.all(0 <= tgt_len).item()
                and torch.all(tgt_len <= tgt_max_len).item()
            ):
                raise ValueError("Invalid sequence lengths")
        if src_enc.shape[-1] != self.src_enc_dim:
            raise ValueError()
        if tgt_emb.shape[-1] != self.tgt_emb_dim:
            raise ValueError()
        return self._decode(src_enc, src_len, tgt_emb, tgt_len=tgt_len)


class IdentityDecoder(Decoder):
    def get_tgt_dec_dim(self):
        return self.tgt_emb_dim

    def _decode(self, src_enc, src_len, tgt_emb, tgt_len=None):
        return tgt_emb


class TransformerDecoder(Decoder):
    def __init__(
        self,
        src_enc_dim,
        tgt_emb_dim,
        model_dim=512,
        num_heads=8,
        num_layers=6,
        feedforward_dim=2048,
        dropout_p=0.1,
    ):
        if src_enc_dim != model_dim or tgt_emb_dim != model_dim:
            raise ValueError()

        super().__init__(src_enc_dim, tgt_emb_dim)

        transformer_layer = nn.modules.TransformerDecoderLayer(
            model_dim,
            num_heads,
            dim_feedforward=feedforward_dim,
            dropout=dropout_p,
            activation="relu",
        )
        transformer_norm = nn.modules.normalization.LayerNorm(model_dim)
        self.transformer = nn.modules.TransformerDecoder(
            transformer_layer, num_layers, norm=transformer_norm
        )

        _xavier_init_params(self.parameters())

        self.model_dim = model_dim

    def get_tgt_dec_dim(self):
        return self.model_dim

    def _decode(self, src_enc, src_len, tgt_emb, tgt_len=None):
        src_max_len, batch_size, _ = src_enc.shape
        tgt_max_len, _, _ = tgt_emb.shape

        # Create src mask (based on sequence length)
        seq_idxs = torch.arange(
            0, src_max_len, dtype=src_len.dtype, device=src_enc.device
        ).expand(batch_size, -1)
        # NOTE: True means *do* mask that position
        src_key_padding_mask = seq_idxs >= src_len.unsqueeze(1)

        # Create tgt mask (causal)
        tgt_mask = (
            torch.triu(
                torch.ones(
                    (tgt_max_len, tgt_max_len), dtype=torch.bool, device=tgt_emb.device
                )
            )
            == 1
        ).transpose(0, 1)
        tgt_mask = (    
            tgt_mask.float()
            .masked_fill(tgt_mask == 0, float("-inf"))
            .masked_fill(tgt_mask == 1, float(0.0))
        )

        return self.transformer(
            tgt_emb,
            src_enc,
            tgt_mask=tgt_mask,
            memory_key_padding_mask=src_key_padding_mask,
        )


class _TransducerImpl(nn.Module):
    '''这是一个核心实现，负责将“嵌入层”、“编码器”和（可选的）“解码器”整合起来。'''
    def __init__(
        self,
        src_emb_mode="identity",
        src_vocab_size=None,
        src_dim=None,
        src_emb_dim=None,
        src_pos_emb=False,
        src_dropout_p=0,
        enc_cls=IdentityEncoder,
        enc_kwargs={},
        tgt_emb_mode="identity",
        tgt_vocab_size=None,
        tgt_dim=None,
        tgt_emb_dim=None,
        tgt_pos_emb=False,
        tgt_dropout_p=0,
        dec_cls=None,
        dec_kwargs={},
    ):
        super().__init__()

        # Init src embed
        self.src_emb = None
        if src_emb_mode == "identity":  # 直接使用输入数据
            src_emb_dim = src_dim
        elif src_emb_mode == "project": # 通过一个线性层将输入投影到期望的嵌入维度
            if src_dim is None or src_emb_dim is None:
                raise ValueError()
            self.src_emb = nn.Linear(src_dim, src_emb_dim)
        elif src_emb_mode == "embed":   # 使用 _TokenEmbedding 将 token id 转换为嵌入向量
            if src_vocab_size is None or src_emb_dim is None:
                raise ValueError()
            self.src_emb = _TokenEmbedding(src_vocab_size, src_emb_dim)
        else:
            raise ValueError()
        self.src_pos_emb = None
        if src_pos_emb:
            if src_emb_dim is None:
                raise ValueError()
            self.src_pos_emb = _PositionalEmbedding(src_emb_dim)
        self.src_dropout = None
        if src_dropout_p > 0:
            self.src_dropout = nn.Dropout(p=src_dropout_p)

        # Init encoder
        self.enc = enc_cls(src_emb_dim, **enc_kwargs)

        # Init tgt embed
        self.tgt_emb = None
        if tgt_emb_mode == "identity":
            tgt_emb_dim = tgt_dim
        elif tgt_emb_mode == "project":
            if tgt_dim is None or tgt_emb_dim is None:
                raise ValueError()
            self.tgt_emb = nn.Linear(tgt_dim, tgt_emb_dim)
        elif tgt_emb_mode == "embed":
            if tgt_vocab_size is None or tgt_emb_dim is None:
                raise ValueError()
            self.tgt_emb = _TokenEmbedding(tgt_vocab_size, tgt_emb_dim)
        else:
            raise ValueError()
        self.tgt_pos_emb = None
        if tgt_pos_emb:
            if tgt_emb_dim is None:
                raise ValueError()
            self.tgt_pos_emb = _PositionalEmbedding(tgt_emb_dim)
        self.tgt_dropout = None
        if tgt_dropout_p > 0:
            self.tgt_dropout = nn.Dropout(p=tgt_dropout_p)

        # Init decoder  选择是否用decoder
        self.dec = None
        if dec_cls is not None:
            self.dec = dec_cls(self.enc.get_src_enc_dim(), tgt_emb_dim, **dec_kwargs)

    def encode(self, src, src_len):
        src_max_len, batch_size, _ = src.shape

        # Embed src
        src_emb = src
        if self.src_emb is not None:
            src_emb = src_emb.reshape(src_max_len * batch_size, -1)
            src_emb = self.src_emb(src_emb)
            src_emb = src_emb.reshape(src_max_len, batch_size, -1)
        if self.src_pos_emb is not None:
            src_emb = self.src_pos_emb(src_emb)
        if self.src_dropout is not None:
            src_emb = self.src_dropout(src_emb)

        return self.enc(src_emb, src_len)

    def decode(self, src_enc, src_len, tgt, tgt_len=None):
        if self.dec is None:
            raise Exception()

        tgt_max_len, batch_size = tgt.shape

        # Embed tgt
        tgt_emb = tgt
        if self.tgt_emb is not None:
            tgt_emb = tgt_emb.view(tgt_max_len * batch_size, -1)
            tgt_emb = self.tgt_emb(tgt_emb)
            tgt_emb = tgt_emb.view(tgt_max_len, batch_size, -1)
        if self.tgt_pos_emb is not None:
            tgt_emb = self.tgt_pos_emb(tgt_emb)
        if self.tgt_dropout is not None:
            tgt_emb = self.tgt_dropout(tgt_emb)

        return self.dec(src_enc, src_len, tgt_emb, tgt_len=tgt_len)

    def forward(self, src, src_len, tgt, tgt_len=None):
        raise NotImplementedError()


class EncOnlyTransducer(_TransducerImpl):
    '''继承自 _TransducerImpl，专注于仅对输入序列进行编码的场景，比如序列分类、回归等任务。
    其并不强制要求使用某一种具体的 encoder，而是通过父类 _TransducerImpl 中的参数 enc_cls 来决定具体使用哪种编码器。'''
    def __init__(self, output_dim, **kwargs):
        super().__init__(
            tgt_emb_mode="identity",
            tgt_vocab_size=None,
            tgt_dim=None,
            tgt_emb_dim=None,
            tgt_pos_emb=False,
            dec_cls=None,
            dec_kwargs={},
            **kwargs,
        )
        # 用于将编码器的输出映射到所需的输出维度
        self.output = nn.Linear(self.enc.get_src_enc_dim(), output_dim)

    def decode(self, src_enc, src_len, tgt, tgt_len=None):
        raise Exception()

    def forward(self, src, src_len, tgt=None, tgt_len=None):
        src_max_len, batch_size, _ = src.shape

        src_enc = self.encode(src, src_len)

        out = src_enc
        out = out.view(src_max_len * batch_size, -1)
        out = self.output(out)
        out = out.view(src_max_len, batch_size, -1)

        return out


class SimpleEncoderOnlyTransformer(nn.Module):
    def __init__(
        self,
        src_dim: int,         # 输入特征维度
        output_dim: int,      # 输出类别数
        model_dim: int = 256, # Transformer hidden size
        num_heads: int = 4,
        num_layers: int = 3,
        feedforward_dim: int = 1024,
        dropout_p: float = 0.1,
        use_pos_emb: bool = True,
    ):
        super().__init__()
        self.model_dim = model_dim
        self.use_pos_emb = use_pos_emb

        # 1) 线性投影，把输入特征 src_dim -> model_dim
        self.input_proj = nn.Linear(src_dim, model_dim)

        # 2) 可选：可学习位置编码 [max_len, model_dim]
        #    如果想换成正余弦位置编码，也可自行替换
        if self.use_pos_emb:
            # 假定序列最大长度是2000，可根据实际需要调整
            self.pos_emb = nn.Embedding(2000, model_dim)  
        else:
            self.pos_emb = None

        # 3) Transformer Encoder (PyTorch 内置)
        # 注意：旧版 PyTorch 不支持 batch_first 参数，此时默认输入形状是 [S, N, E]
        # 这里 S=序列长度, N=批大小, E=embedding维度
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=model_dim,
            nhead=num_heads,
            dim_feedforward=feedforward_dim,
            dropout=dropout_p
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        # 4) 输出层：把 [S, N, model_dim] -> [S, N, output_dim]
        self.output_fc = nn.Linear(model_dim, output_dim)

    def forward(self, src, src_len=None):
        """
        src: [T, B, src_dim]
        src_len: [B], 表示每个样本的实际长度 (可用于生成 padding_mask)
        返回: logits => [T, B, output_dim]
        """
        T, B, _ = src.shape

        # (1) 线性投影到 model_dim
        x = self.input_proj(src)  # => [T, B, model_dim]

        # (2) 如果要加位置编码
        if self.pos_emb is not None:
            # 生成 [T, B] 的位置索引，然后查表
            positions = torch.arange(T, device=src.device).unsqueeze(1).expand(T, B)  # [T,B]
            pos_encoding = self.pos_emb(positions)  # [T,B,model_dim]
            x = x + pos_encoding

        # (3) 构造 key_padding_mask (如果需要)
        #     PyTorch 内置Transformer：需要 [N, S] 形状的 bool mask，True=要mask
        #     这里 S=序列维度, N=batch维度
        if src_len is not None:
            seq_idxs = torch.arange(T, device=src.device).expand(B, T)  # [B, T]
            key_padding_mask = seq_idxs >= src_len.unsqueeze(1)         # True=padding
        else:
            key_padding_mask = None

        # (4) 进入 Transformer Encoder
        #     默认输入 [S,N,E], 即 [T,B,model_dim]
        #     src_key_padding_mask shape => [N,S]
        x = self.transformer_encoder(
            x,  # [T,B,model_dim]
            src_key_padding_mask=key_padding_mask  # [B,T], True=mask
        )  # => [T,B,model_dim]

        # (5) 输出层
        logits = self.output_fc(x)  # => [T,B,output_dim]

        return logits