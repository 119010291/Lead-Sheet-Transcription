#!/usr/bin/env python3
"""
train_preprocessing_hooktheory.py

此脚本结合:
1) 从 Hooktheory.json.gz 中读取并筛选训练集
2) 对每条训练样本:
   a) 解析 alignment => 获取 beats/times
   b) 从已下载的 mp4/webm/m4a 中截取音频 (start_time ~ end_time) 到临时 .wav
   c) 调用和 infer.py 类似的函数 (beat_tracking, extract_features, etc.)
   d) 保存输出(特征 + 对齐信息)到本地文件 (.npz)
"""

import os
import gzip
import json
import numpy as np
import logging
import librosa
from tqdm import tqdm
import subprocess

# 如果你在 sheetsage.infer 里有这三个函数, 就 from 那里 import:
from sheetsage.infer import (
    _extract_features,
    _beat_tracking_with_hints,
    _split_into_chunks,
    InputFeats  # 确保 InputFeats 被导入
)


###############################################
# 1) 定义 Interval -> 家族 映射 + 8大家族
###############################################
# 仅示例，你应根据实际数据增减
INTERVALS_TO_FAMILY = {
    (4, 3): "",       # major triad
    (3, 4): "m",      # minor triad
    (4, 3, 3): "7",   # dom7
    (3, 4, 3): "m7",
    (4, 3, 4): "maj7",
    (5, 2): "sus",    # 可能只表示三和弦
    (3, 3): "dim",
    (4, 4): "aug",
    # 如果有更多，比如 (3,3,3)->dim7 或 (3,3,4)->m7b5 等不在原8 family里面，就可以统一视作 UNK
    # ... 
}
# 八大家族
_HARMONY_FAMILIES = ["", "m", "m7", "7", "maj7", "sus", "dim", "aug"]
# 由此 12 (根音) × 8 (家族) = 96，再 +1 表示 <UNK>=0

def chord_event_to_label(chord_evt):
    """
    将一个和声事件映射为 [0..96] 间的整数标签。
    0 表示 <UNK>； 1..96 => root*8 + family_idx + 1
    忽略 inversion.
    chord_evt: {
      "onset": float, "offset": float,
      "root_pitch_class": int (0..11),
      "root_position_intervals": List[int],
      "inversion": int (可有可无, 忽略),
      ...
    }
    """
    root = chord_evt["root_pitch_class"]
    intervals = tuple(chord_evt["root_position_intervals"])  # e.g. (4,3) (3,4,3)...

    # 1) 根据 intervals 找到家族
    if intervals not in INTERVALS_TO_FAMILY:
        # 不在八大家族列表 => label=0
        return 0
    fam_name = INTERVALS_TO_FAMILY[intervals]
    if fam_name not in _HARMONY_FAMILIES:
        # 虽在INTERVALS_TO_FAMILY里，但不在 8 families => 仍记为UNK
        return 0

    fam_idx = _HARMONY_FAMILIES.index(fam_name)
    # 2) label = root*8 + fam_idx + 1
    label_id = root * len(_HARMONY_FAMILIES) + fam_idx + 1
    if label_id > 96:
        # 理论上不会
        return 0
    return label_id


def offline_label(chunks_features, chunks_tertiaries, tertiaries_times, melody_events, harmony_events):
    '''处理labels'''

    # 为了统一处理，这里把 chunked_features / chunked_tertiaries 都当 object array
    # 如果实际是 (N_chunks,T,feats_dim)，可以改写成 for i in range(N_chunks): feats_i = chunked_features[i, ...]
    # 这里示例: shape=(N_chunks,) => chunked_features[i] shape=(T_i, feats_dim)
    # 同样 chunked_tertiaries[i] shape=(T_i,)
    N_chunks = len(chunks_features)

    # 我们先准备一个列表, 存每个 chunk 的标签
    chunked_melody_list = []
    chunked_harmony_list = []

    for i in range(N_chunks):
        feats_i = chunks_features[i]          # [T_i, feats_dim]
        chunked_tertiary = chunks_tertiaries[i]    # 来到对应的chunk帧
        times_i = tertiaries_times[chunked_tertiary][:-1]        # [T_i], 每帧绝对时间(秒),由于t_i帧覆盖的区间是 [t_i, t_{i+1}),所以会多一帧
        T_i = feats_i.shape[0]
        assert T_i == times_i.shape[0], "帧数不匹配!"

        labels_mel = np.full((T_i,), -28, dtype=np.int64)  # 默认全是-28(无音)，因为后面还要+28
        labels_har = np.zeros((T_i,), dtype=np.int64)

        # 遍历该 chunk 的每一帧
        for f in range(T_i):
            frame_time = times_i[f]  # 这帧的绝对秒
            print(frame_time)
            # 在 melody_events 找它对应的事件
            for note in melody_events:
                onset = note["onset"]
                offset= note["offset"]
                print(onset, offset)
                # 判断 frame_time 是否落在 [onset, offset)
                if onset <= frame_time < offset:
                    pc = note["pitch_class"]
                    octave = note["octave"]
                    label_id = pc + 12*(octave + 1)  # 例: 把音高映射成 int
                    labels_mel[f] = label_id
                    break
                # 否则就保持默认0 = 无音
            # 找到 harmony_events 中 onset<=frame_time<offset
            for chord_evt in harmony_events:
                if chord_evt["onset"] <= frame_time < chord_evt["offset"]:
                    label_id = chord_event_to_label(chord_evt)
                    labels_har[f] = label_id
                    break
            # 如果没有 chord_evt 覆盖 => 保持0

        chunked_melody_list.append(labels_mel)
        chunked_harmony_list.append(labels_har)

    # 把 labels 组合成对应形状
    # 如果各 chunk 的 T_i 一样，可以直接 stack => [N_chunks, T_i]
    # 否则就只能存成 object array
    same_shape0 = all(chunked_melody_list[0].shape[0] == lbls.shape[0] for lbls in chunked_melody_list)
    if same_shape0:
        chunked_melody_labels = np.stack(chunked_melody_list, axis=0)
    else:
        chunked_melody_labels = np.array(chunked_melody_list, dtype=object)

    same_shape1 = all(chunked_harmony_list[0].shape[0] == lbls.shape[0] for lbls in chunked_harmony_list)
    if same_shape1:
        chunked_harmony_labels = np.stack(chunked_harmony_list, axis=0)
    else:
        chunked_harmony_labels = np.array(chunked_harmony_list, dtype=object)
    
    return chunked_melody_labels, chunked_harmony_labels


def ffmpeg_extract_segment(input_path, output_wav, start_time, end_time):
    """
    用 ffmpeg 从 input_path (可能是 .mp4/.webm/.m4a) 中
    截取区间 [start_time, end_time] 输出到 output_wav (16-bit PCM mono).
    """
    duration = end_time - start_time
    cmd = [
        "ffmpeg", "-y",  # -y: 覆盖输出
        "-ss", str(start_time),
        "-i", input_path,
        "-t", str(duration),
        "-acodec", "pcm_s16le",  # 16-bit PCM
        "-ar", "44100",          # 采样率
        "-ac", "1",              # 单声道
        output_wav
    ]
    ret = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if ret.returncode != 0:
        raise RuntimeError(f"ffmpeg extract failed: {ret.stderr.decode('utf-8', errors='ignore')}")


def preprocess_hooktheory(
    # part_json_path,
    hooktheory_json_gz,
    output_dir,
    input_feats="JUKEBOX",
    measure_per_chunk=4,
    beats_per_measure_hint=None,
    beats_per_minute_hint=None,
    beat_detection_padding=15.0,
    segment_hints_are_downbeats=False,
    legacy_behavior=False,
    test_only=True
):
    """
    1) 读取 Hooktheory.json.gz
    2) 筛选 TRAIN + AUDIO_AVAILABLE + MELODY + 非 TEMPO_CHANGES
    3) 对每个样本:
       - alignment => 算 start_time/end_time
       - 找到已下载的 .mp4/.webm/.m4a => ffmpeg 截取该区间 => partial.wav
       - librosa.load => beat_tracking => extract_features
       - 存 .npz
    """

    os.makedirs(output_dir, exist_ok=True)

    # ------------- (A) 读取并筛选 -------------
    with gzip.open(hooktheory_json_gz, "rt", encoding="utf-8") as f:
        dataset = json.load(f)
    # logging.info(f"Total examples in Hooktheory: {len(dataset)}")

    train_set = {
        k: v for k, v in dataset.items()
        if v["split"] == "TRAIN"
        and "AUDIO_AVAILABLE" in v["tags"]
        and "MELODY" in v["tags"]
        and "TEMPO_CHANGES" not in v["tags"]
    }
    logging.info(f"Filtered train set size: {len(train_set)}")

    # 假设你在 HPC 上通过新环境下载，
    # 把文件放在 /home/dw3180/sheetsage_project/audio_downloaded/ 下，
    # 老容器里 bind 到 /sheetsage/audio_downloaded
    downloaded_dir = "/sheetsage/audio_downloaded/train"  # 容器内可访问
    possible_exts = [".mp4", ".webm", ".m4a"]       # 可能出现的后缀

    if test_only:
        
        first_uid = "-Wegl__JmrY"
        # 只构建一个 dict
        train_set = {first_uid: train_set[first_uid]}
        logging.info(f"[TEST_ONLY] Will process just this uid={first_uid}")

    # ------------- (B) 遍历样本 -------------
    # with open(part_json_path,"r", encoding="utf-8") as f:
    #     part_dict = json.load(f)
    for uid, example in tqdm(train_set.items(), desc="Preprocessing Hooktheory"):
        try:
            out_npz = os.path.join(output_dir, f"{uid}.npz")
            # ---- 关键1：检查产物是否已存在 ----
            # if os.path.exists(out_npz):
            #     logging.info(f"UID={uid} already processed, skipping.")
            #     continue

            # (1) 解析 alignment
            refined = example["alignment"]["refined"]
            beats_arr = refined["beats"]
            times_arr = refined["times"]
            num_beats = example["annotations"]["num_beats"]

            # 插值得到 beat->time
            from scipy.interpolate import interp1d
            beat_to_time_fn = interp1d(
                beats_arr,
                times_arr,
                kind="linear",
                fill_value="extrapolate"
            )
            start_time = float(beat_to_time_fn(0))
            end_time   = float(beat_to_time_fn(num_beats))

            # (2) 找到已下载的音频文件: audio_{uid}.(mp4|webm|m4a)
            main_file_path = None
            for ext in possible_exts:
                test_path = os.path.join(downloaded_dir, f"audio_{uid}{ext}")
                if os.path.exists(test_path):
                    main_file_path = test_path
                    break
            if not main_file_path:
                logging.error(f"No mp4/webm/m4a found for uid={uid}, skip.")
                continue

            # (2b) 用 ffmpeg 截取 => tmp_{uid}.wav
            wav_path = f"tmp_{uid}.wav"
            ffmpeg_extract_segment(main_file_path, wav_path, start_time, end_time)

            # (2c) librosa.load 读刚截好的小片段
            audio, sr = librosa.load(wav_path, sr=None, mono=True)

            # # (3a) 初始化提取器
            try:
                input_feats_enum = InputFeats[input_feats.upper()]
            except KeyError:
                raise ValueError(f"Unsupported input_feats: {input_feats}. Supported options are {[feat.name for feat in InputFeats]}")
    

            # (3b) beat_tracking
            (
                beats_per_measure,
                beats,
                beats_times,
                tertiaries,
                tertiaries_times,
                segment_start_downbeat,
                segment_end_beat,
            ) = _beat_tracking_with_hints(
                wav_path,
                segment_start_hint=None,
                segment_end_hint=None,
                segment_hints_are_downbeats=segment_hints_are_downbeats,
                beats_per_measure_hint=beats_per_measure_hint,
                beats_per_minute_hint=beats_per_minute_hint,
                beat_detection_padding=beat_detection_padding,
                legacy_behavior=legacy_behavior
            )

            # (3c) split into chunks
            chunks_tertiaries = _split_into_chunks(
                tertiaries_times,
                measure_per_chunk,
                beats_per_measure,
                segment_start_downbeat,
                segment_end_beat,
                avoid_chunking_if_possible=True,
                legacy_behavior=legacy_behavior
            )

            # (3d) extract features
            chunks_features = _extract_features(
                wav_path,
                input_feats=input_feats_enum,  # 使用枚举成员,
                tertiaries_times=tertiaries_times,
                chunks_tertiaries=chunks_tertiaries,
                tqdm=tqdm
            )

            # (4) 从 all_json 中取出 melody & harmony events
            melody_dict = dataset[uid]  # {"melody": [...], ...}
            melody_events = melody_dict['annotations']["melody"]
            if not melody_events:
                print(f"[WARN] uid={uid} has no 'melody', skip.")
            harmony_dict = dataset[uid]
            harmony_events = harmony_dict['annotations']["harmony"]
            if not harmony_events:
                print(f"[WARN] uid={uid} has no 'harmony', skip.")

            chunks_labels, chunks_labels_harmony = offline_label(
                chunks_features=chunks_features,
                chunks_tertiaries=chunks_tertiaries,
                tertiaries_times=tertiaries_times,
                melody_events=melody_events,
                harmony_events=harmony_events
            )

            # (5) 保存结果
            np.savez_compressed(
                out_npz,
                sr=sr,
                beats_per_measure=beats_per_measure,
                beats=beats,
                beats_times=beats_times,
                tertiaries_times=tertiaries_times,
                chunks_tertiaries=chunks_tertiaries,
                chunks_features=chunks_features,
                chunks_labels=chunks_labels,
                chunks_labels_harmony=chunks_labels_harmony
            )
            logging.info(f"Saved {out_npz}")

            # (5) 删除临时 wav
            # if os.path.exists(wav_path):
            #     os.remove(wav_path)

        except Exception as e:
            logging.error(f"Failed preprocessing uid={uid}, reason={e}")
            continue

    logging.info("All done!")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Preprocess Hooktheory dataset for training (Old environment, no direct youtube download).")
    parser.add_argument("hooktheory_json_gz", type=str, help="Path to Hooktheory.json.gz")
    # parser.add_argument("--part_json", type=str, required=True,
    #     help="Path to splitted train_set_part{i}.json")
    parser.add_argument("--output_dir", type=str, help="Where to store .npz features")
    parser.add_argument("--input_feats", default="JUKEBOX", choices=["JUKEBOX","HANDCRAFTED"], help="Input features type")
    parser.add_argument("--measure_per_chunk", type=int, default=4)
    parser.add_argument("--beat_detection_padding", type=float, default=15.0)
    parser.add_argument("--test_only", action="store_true", help="If set, only processes the first matching sample.")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    preprocess_hooktheory(
        args.hooktheory_json_gz,
        # args.part_json,
        args.output_dir,
        input_feats=args.input_feats,
        measure_per_chunk=args.measure_per_chunk,
        beat_detection_padding=args.beat_detection_padding,
        test_only=args.test_only
    )
