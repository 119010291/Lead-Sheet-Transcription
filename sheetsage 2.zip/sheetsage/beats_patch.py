#!/usr/bin/env python3
"""
用来补上beats信息，使用run_preprocessing.sh
"""

import os
import gzip
import json
import numpy as np
import logging
import librosa
from tqdm import tqdm
import subprocess
import shutil
import pretty_midi



# 如果你在 sheetsage.infer 里有这三个函数, 就 from 那里 import:
from sheetsage.infer import (
    _extract_features,
    _beat_tracking_with_hints,
    _split_into_chunks,
    InputFeats  # 确保 InputFeats 被导入
)

def ffmpeg_extract_segment(input_path, output_wav, start_time, end_time):
    """
    用 ffmpeg 从 input_path (可能是 .mp4/.webm/.m4a) 中
    截取区间 [start_time, end_time] 输出到 output_wav (16-bit PCM mono).
    """
    duration = end_time - start_time
    cmd = [
        "ffmpeg", "-y",  # -y: 覆盖输出
        "-ss", str(start_time),
        "-i", input_path,
        "-t", str(duration),
        "-acodec", "pcm_s16le",  # 16-bit PCM
        "-ar", "44100",          # 采样率
        "-ac", "1",              # 单声道
        output_wav
    ]
    ret = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if ret.returncode != 0:
        raise RuntimeError(f"ffmpeg extract failed: {ret.stderr.decode('utf-8', errors='ignore')}")


def preprocess_hooktheory(
    # part_json_path,
    hooktheory_json_gz,
    output_dir,
    input_feats="JUKEBOX",
    measure_per_chunk=4,
    beats_per_measure_hint=None,
    beats_per_minute_hint=None,
    beat_detection_padding=15.0,
    segment_hints_are_downbeats=False,
    legacy_behavior=False,
    test_only=False
):
    """
    1) 读取 Hooktheory.json.gz
    2) 筛选 TRAIN + AUDIO_AVAILABLE + MELODY + 非 TEMPO_CHANGES
    3) 对每个样本:
       - alignment => 算 start_time/end_time
       - 找到已下载的 .mp4/.webm/.m4a => ffmpeg 截取该区间 => partial.wav
       - librosa.load => beat_tracking => extract_features
       - 存 .npz
    """

    os.makedirs(output_dir, exist_ok=True)

    # ------------- (A) 读取并筛选 -------------
    with gzip.open(hooktheory_json_gz, "rt", encoding="utf-8") as f:
        dataset = json.load(f)
    # logging.info(f"Total examples in Hooktheory: {len(dataset)}")

    train_set = {
        k: v for k, v in dataset.items()
        if v["split"] == "TEST"
        and "AUDIO_AVAILABLE" in v["tags"]
        and "MELODY" in v["tags"]
        and "TEMPO_CHANGES" not in v["tags"]
    }
    logging.info(f"Filtered train set size: {len(train_set)}")

    # 假设你在 HPC 上通过新环境下载，
    # 把文件放在 /home/dw3180/sheetsage_project/audio_downloaded/ 下，
    # 老容器里 bind 到 /sheetsage/audio_downloaded
    downloaded_dir = "/sheetsage/audio_downloaded/test"  # 容器内可访问
    possible_exts = [".mp4", ".webm", ".m4a"]       # 可能出现的后缀

    if test_only:
        
        first_uid = "-kwxAMkXxKG"
        # 只构建一个 dict
        train_set = {first_uid: train_set[first_uid]}
        logging.info(f"[TEST_ONLY] Will process just this uid={first_uid}")

    # ------------- (B) 遍历样本 -------------
    # with open(part_json_path,"r", encoding="utf-8") as f:
    #     part_dict = json.load(f)
    for uid, example in tqdm(train_set.items(), desc="Preprocessing Hooktheory"):
        try:
            out_npz = os.path.join(output_dir, f"{uid}.npz")
            data = np.load(out_npz, allow_pickle=True)
            
            # (1) 解析 alignment
            refined = example["alignment"]["refined"]
            beats_arr = refined["beats"]
            times_arr = refined["times"]
            num_beats = example["annotations"]["num_beats"]

            # 插值得到 beat->time
            from scipy.interpolate import interp1d
            beat_to_time_fn = interp1d(
                beats_arr,
                times_arr,
                kind="linear",
                fill_value="extrapolate"
            )
            start_time = float(beat_to_time_fn(0))
            end_time   = float(beat_to_time_fn(num_beats))

            # (2) 找到已下载的音频文件: audio_{uid}.(mp4|webm|m4a)
            main_file_path = None
            for ext in possible_exts:
                test_path = os.path.join(downloaded_dir, f"audio_{uid}{ext}")
                if os.path.exists(test_path):
                    main_file_path = test_path
                    break
            if not main_file_path:
                logging.error(f"No mp4/webm/m4a found for uid={uid}, skip.")
                continue

            # (2b) 用 ffmpeg 截取 => tmp_{uid}.wav
            wav_path = f"tmp_{uid}.wav"
            ffmpeg_extract_segment(main_file_path, wav_path, start_time, end_time)

            # (2c) librosa.load 读刚截好的小片段
            audio, sr = librosa.load(wav_path, sr=None, mono=True)


            # (3b) beat_tracking
            (
                beats_per_measure,
                beats,
                beats_times,
                tertiaries,
                tertiaries_times,
                segment_start_downbeat,
                segment_end_beat,
            ) = _beat_tracking_with_hints(
                wav_path,
                segment_start_hint=None,
                segment_end_hint=None,
                segment_hints_are_downbeats=segment_hints_are_downbeats,
                beats_per_measure_hint=beats_per_measure_hint,
                beats_per_minute_hint=beats_per_minute_hint,
                beat_detection_padding=beat_detection_padding,
                legacy_behavior=legacy_behavior
            )

            

            # (5) 保存结果
            new_data = dict(data)
            new_data["beats"] = beats
            np.savez(out_npz, **new_data)


            # (5) 删除临时 wav
            if os.path.exists(wav_path):
                os.remove(wav_path)

        except Exception as e:
            logging.error(f"Failed preprocessing uid={uid}, reason={e}")
            continue

    logging.info("All done!")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Preprocess Hooktheory dataset for training (Old environment, no direct youtube download).")
    parser.add_argument("hooktheory_json_gz", type=str, help="Path to Hooktheory.json.gz")
    # parser.add_argument("--part_json", type=str, required=True,
    #     help="Path to splitted train_set_part{i}.json")
    parser.add_argument("--output_dir", type=str, help="Where to store .npz features")
    parser.add_argument("--input_feats", default="JUKEBOX", choices=["JUKEBOX","HANDCRAFTED"], help="Input features type")
    parser.add_argument("--measure_per_chunk", type=int, default=8)
    parser.add_argument("--beat_detection_padding", type=float, default=15.0)
    parser.add_argument("--test_only", action="store_true", help="If set, only processes the first matching sample.")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    preprocess_hooktheory(
        args.hooktheory_json_gz,
        # args.part_json,
        args.output_dir,
        input_feats=args.input_feats,
        measure_per_chunk=args.measure_per_chunk,
        beat_detection_padding=args.beat_detection_padding,
        test_only=args.test_only
    )
