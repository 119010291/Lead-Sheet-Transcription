import json
import logging
import pathlib
import pickle
import shutil
from collections import defaultdict

import numpy as np
import torch
from tqdm import tqdm

try:
    import wandb as wandb_lib
except ModuleNotFoundError as e:
    pass

from . import set_seed


def train(
    exp_name,
    cfg,
    run_root_dir,
    get_datasets_and_collate_fn,
    create_model,
    compute_loss,
    compute_eval_metrics,
    src_dirs=None,
    src_remote_dirs=None,
    data_num_workers=4,
    eval_num_workers=4,
    wandb=False,
    tqdm=lambda x, total=None: x,
):
    # Create run_dir
    run_dir = pathlib.Path(run_root_dir, exp_name)
    run_dir.mkdir(parents=True, exist_ok=True)

    # Determine if resuming
    ckpt_paths = [p for p in run_dir.glob("*.pt") if any(c.isdigit() for c in p.name)]
    cfg_paths = list(run_dir.glob("*.cfg.json"))
    resuming = (
        len(ckpt_paths) > 0
        and len(cfg_paths) == 1
        and cfg_paths[0].stem.split(".")[0] == cfg.uid()
    )
    if resuming:
        step = 0
        ckpt_path = None
        for path in ckpt_paths:
            ckpt_step = int("".join([c for c in path.name if c.isdigit()]))
            if ckpt_step > step:
                step = ckpt_step
                ckpt_path = path
        logging.info(f"Resuming from {ckpt_path} @ step {step}")
    else:
        step = 0
        ckpt_path = None
        with open(pathlib.Path(run_dir, f"{cfg.uid()}.cfg.json"), "w") as f:
            f.write(cfg.serialize())
        logging.info(f"Training from scratch")

    # Start WnB, set up the experiment (weights and biases)
    if wandb:
        wandb_lib.init(
            project="sheetsage",
            name=exp_name,
            config=cfg,
            save_code=False,
            reinit=True,
        )

    # Copy src from mounted remote to local
    if src_dirs is not None:
        src_dirs = [pathlib.Path(src_dir).resolve() for src_dir in src_dirs]
        if src_remote_dirs is not None:
            for src_dir, src_remote_dir in zip(src_dirs, src_remote_dirs):
                src_remote_dir = pathlib.Path(src_remote_dir).resolve()
                src_dir.mkdir(parents=True, exist_ok=True)
                logging.info(f"Copying {src_remote_dir} -> {src_dir}")  # 如果给了 src_remote_dirs，则从这些远程目录复制数据到本地 src_dirs
                for remote_path in tqdm(list(src_remote_dir.glob("*.npy"))):
                    path = pathlib.Path(src_dir, remote_path.name)
                    if not path.is_file():
                        shutil.copy(remote_path, path)

    # Create data loaders
    set_seed(cfg["seed"])
    train_dataset, eval_dataset, collate_fn = get_datasets_and_collate_fn(
        cfg,
        src_dirs=src_dirs,
        train_cache=src_remote_dirs is None,
        eval_split="valid",
        tqdm=tqdm,
    )
    train_sampler = torch.utils.data.RandomSampler(train_dataset)
    train_dataloader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=cfg["batch_size"],
        sampler=train_sampler,
        num_workers=0 if src_remote_dirs is None else data_num_workers,
        collate_fn=collate_fn,
        # NOTE: Pinning was slower at some point but this could change in future
        pin_memory=False,
        drop_last=True,
        # NOTE: Unavailable in PyTorch 1.4.0
        # prefetch_factor=4,
        # persistent_workers=True,
    )
    eval_sampler = torch.utils.data.SequentialSampler(eval_dataset)
    eval_dataloader = torch.utils.data.DataLoader(
        eval_dataset,
        batch_size=cfg["batch_size"],
        sampler=eval_sampler,
        num_workers=0,  # NOTE: Eval dataset caches in memory so we don't want workers
        collate_fn=collate_fn,
        # NOTE: Pinning was slower at some point but this could change in future
        pin_memory=False,
        drop_last=False,
        # NOTE: Unavailable in PyTorch 1.4.0
        # prefetch_factor=4,
        # persistent_workers=True,
    )

    # Create model
    set_seed(cfg["seed"])   # 确保数据加载次序可复现
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = create_model(cfg, device)   # 根据配置文件 cfg 创建模型实例，将模型转移到指定的计算设备（CPU 或 GPU）
    model.train()   # 将模型设置为训练模式，和inference对应
    logging.info("-" * 80)
    for n, p in model.named_parameters():
        logging.info(f"{n}, {p.shape}")

    # Create optimizer
    set_seed(cfg["seed"])
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg["lr"])

    # Load parameters
    if resuming:
        d = torch.load(ckpt_path)
        model.load_state_dict(d["model"])
        model.train()
        optimizer.load_state_dict(d["optimizer"])
        del d

    # Set seed for data ordering
    set_seed(cfg["seed"])

    eval_best_early_stop = float("-inf")
    eval_best_loss = float("inf")
    eval_best_metrics = {}
    while True:
        if cfg["max_num_steps"] is not None and step >= cfg["max_num_steps"]:
            break

        for batch in train_dataloader:
            if step % cfg["eval_frequency"] == 0:
                model.eval()

                # Run model on entire dataset and store results in memory
                eval_all = defaultdict(list)
                eval_all_losses = defaultdict(list)
                with torch.no_grad():
                    for eval_batch in eval_dataloader:
                        eval_batch = tuple(tensor.to(device) for tensor in eval_batch)
                        eval_logits = model(*eval_batch[:4])
                        eval_loss, eval_losses = compute_loss(
                            cfg, eval_logits, *eval_batch[1:], reduction="none"
                        )
                        eval_all[0].append(eval_logits.cpu().numpy())
                        for i in range(len(eval_batch)):
                            if i == 0:
                                continue
                            eval_all[i].append(eval_batch[i].cpu().numpy())
                        eval_all_losses["loss"].append(eval_loss.cpu().numpy())
                        for k, v in eval_losses.items():
                            eval_all_losses[k].append(v.cpu().numpy())
                eval_all = {
                    k: np.concatenate(batches, axis=0 if batches[0].ndim == 1 else 1)
                    for k, batches in eval_all.items()
                }
                eval_all_losses = {
                    k: np.concatenate(batches, axis=0)
                    for k, batches in eval_all_losses.items()
                }

                # Compute eval metrics
                # NOTE: Running on entire dataset for metrics that threshold globally
                eval_all_tgt_lens = eval_all[3]
                eval_all_metrics = compute_eval_metrics(
                    cfg,
                    *tuple(eval_all[i] for i in range(6)),
                    num_workers=eval_num_workers,
                )
                del eval_all

                # Average into scalars
                eval_metrics = {}
                for k, v in eval_all_metrics.items():
                    eval_metrics[f"eval_{k}"] = np.mean(v)
                for k, v in eval_all_losses.items():
                    eval_metrics[f"eval_{k}_micro"] = np.sum(v) / np.sum(
                        eval_all_tgt_lens
                    )
                    nonempty = np.array(eval_all_tgt_lens) > 0
                    eval_metrics[f"eval_{k}"] = np.mean(
                        np.array(v)[nonempty] / np.array(eval_all_tgt_lens)[nonempty]
                    )

                logging.info(f"{step},eval,{eval_metrics}")
                if wandb:
                    wandb_lib.log(eval_metrics, step=step)

                def _save_model(tag):
                    torch.save(
                        {
                            "step": step,
                            "model": model.state_dict(),
                            "optimizer": optimizer.state_dict(),
                        },
                        pathlib.Path(run_dir, f"{tag}.pt"),
                    )
                    with open(pathlib.Path(run_dir, f"{tag}_step.pkl"), "wb") as f:
                        pickle.dump(step, f)
                    logging.info(f"Saved {tag} at step {step}")

                if (
                    "eval_early_stop" in eval_metrics
                    and eval_metrics["eval_early_stop"] > eval_best_early_stop
                ):
                    _save_model("best_early_stop")
                    eval_best_early_stop = eval_metrics["eval_early_stop"]

                if eval_metrics["eval_loss_micro"] < eval_best_loss:
                    _save_model("best_loss")
                    eval_best_loss = eval_metrics["eval_loss_micro"]

                model.train()

            batch = tuple(tensor.to(device) for tensor in batch)
            optimizer.zero_grad()
            logits = model(*batch[:4])
            loss, losses = compute_loss(cfg, logits, *batch[1:], reduction="mean")
            loss.backward()
            optimizer.step()
            step += 1

            if step % cfg["summarize_frequency"] == 0:
                metrics = {k: v.item() for k, v in losses.items()}
                metrics["loss"] = loss.item()
                logging.debug(f"{step},summary,{metrics}")
                if wandb:
                    wandb_lib.log(metrics, step=step)

            if cfg["max_num_steps"] is not None and step >= cfg["max_num_steps"]:
                break

    return eval_best_early_stop, eval_best_loss


if __name__ == "__main__":
    import importlib
    import os
    from argparse import ArgumentParser

    from tqdm import tqdm

    parser = ArgumentParser()
    parser.add_argument("exp_name", type=str)
    parser.add_argument("exp_module", type=str)
    parser.add_argument("exp_cfg_path", type=str)
    parser.add_argument("run_root_dir", type=str)
    parser.add_argument("src_dirs", type=str)
    parser.add_argument("--src_remote_dirs", type=str)
    parser.add_argument("--data_num_workers", type=int)
    parser.add_argument("--eval_num_workers", type=int)
    parser.add_argument("--wandb", action="store_true")

    parser.set_defaults(
        src_remote_dirs=None,
        data_num_workers=len(os.sched_getaffinity(0)),
        eval_num_workers=len(os.sched_getaffinity(0)),
        wandb=False,
    )

    args = parser.parse_args()

    m = importlib.import_module(args.exp_module)

    with open(args.exp_cfg_path, "r") as f:
        cfg = m.Config(json.load(f))

    logging.basicConfig(level=logging.DEBUG)
    train(
        args.exp_name,
        cfg,
        args.run_root_dir,
        m.get_datasets_and_collate_fn,
        m.create_model,
        m.compute_loss,
        m.compute_eval_metrics,
        src_dirs=args.src_dirs.split(","),
        src_remote_dirs=None
        if args.src_remote_dirs is None
        else args.src_remote_dirs.split(","),
        data_num_workers=args.data_num_workers,
        eval_num_workers=args.eval_num_workers,
        tqdm=tqdm,
        wandb=args.wandb,
    )
