import os
import numpy as np
import torch
import pathlib
import logging
import json
import pytorch_lightning as pl
from .main_lightning import SheetsageLightningModule, Config
from .infer import _format_lead_sheet
from .align import create_beat_to_time_fn

# 在sheetsage_code里用python -m sheetsage.test测试


from functools import lru_cache as cache
from .assets import retrieve_asset
from enum import Enum
from .modules import EncOnlyTransducer, IdentityEncoder, TransformerEncoder
class InputFeats(Enum):
    HANDCRAFTED = 0
    JUKEBOX = 1
    MERT = 2
class Task(Enum):
    MELODY = 0
    HARMONY = 1
class Model(Enum):
    LINEAR = 0
    TRANSFORMER = 1
_MAX_TERTIARIES_PER_CHUNK = 384
_INPUT_TO_DIM = {
    InputFeats.HANDCRAFTED: 229,
    InputFeats.JUKEBOX: 4800,
}
_TASK_TO_VOCAB_SIZE = {Task.MELODY: 89, Task.HARMONY: 97}

@cache()
def _init_model(task, input_feats, model):

    asset_prefix = f"SHEETSAGE_V02_{input_feats.name}_{task.name}"
    with open(retrieve_asset(f"{asset_prefix}_CFG", log=False), "r") as f:
        cfg = json.load(f)
    assert cfg["src_max_len"] == _MAX_TERTIARIES_PER_CHUNK

    src_dim = _INPUT_TO_DIM[input_feats]
    output_dim = _TASK_TO_VOCAB_SIZE[task]

    if cfg["model"] == "probe":
        model = EncOnlyTransducer(
            output_dim,
            src_emb_mode="identity",
            src_vocab_size=None,
            src_dim=src_dim,
            src_emb_dim=None,
            src_pos_emb=False,
            src_dropout_p=0.0,
            enc_cls=IdentityEncoder,
            enc_kwargs={},
        )
    elif cfg["model"] == "transformer":
        model = EncOnlyTransducer(
            output_dim,
            src_emb_mode="project",
            src_vocab_size=None,
            src_dim=src_dim,
            src_emb_dim=512,
            src_pos_emb="pos_emb" in cfg["hacks"],
            src_dropout_p=0.1,
            enc_cls=TransformerEncoder,
            enc_kwargs={
                "model_dim": 512,
                "num_heads": 8,
                "num_layers": 4 if "4layers" in cfg["hacks"] else 6,
                "feedforward_dim": 2048,
                "dropout_p": 0.1,
            },
        )
    else:
        raise ValueError()

    device = torch.device("cpu")
    # device = torch.device("cuda:0")
    model.to(device)
    model.load_state_dict(
        torch.load(
            retrieve_asset(f"{asset_prefix}_MODEL", log=False), map_location=device
        )
    )
    model.eval()
    return model




def save_lead_sheet_as_midi(
    melody_logits,
    harmony_logits,
    beats_per_measure,
    beats,
    beats_times,
    segment_start_downbeat,
    segment_end_beat,
    total_num_tertiary,
    output_midi_path,
    melody_threshold=None,
    harmony_threshold=None
):
    """
    将模型输出 (melody_logits, harmony_logits) 和节拍信息转换成 midi 文件保存下来。

    Args:
        melody_logits: np.ndarray, 模型输出的 melody logits, shape=(total_num_tertiary, melody_vocab_size)
        harmony_logits: np.ndarray, 模型输出的 harmony logits, shape=(total_num_tertiary, harmony_vocab_size)
        beats_per_measure: int, 每小节拍数（如4）
        beats: List[int], 拍号索引序列（如 [0,1,2,3,4,5...]）
        beats_times: List[float], 每个拍号对应的具体时间（单位秒）
        segment_start_downbeat: int, 开始downbeat的索引
        segment_end_beat: int, 结束beat的索引
        total_num_tertiary: int, 该样本的总tertiary数量（也即所有chunk的T长度加总）
        output_midi_path: str or pathlib.Path, midi文件输出位置
        melody_threshold: float or None, 用于解码melody时的阈值（如None则用argmax）
        harmony_threshold: float or None, 用于解码harmony时的阈值（如None则用argmax）
    """

    # 调用原代码已有的_format_lead_sheet，得到lead_sheet对象与拍子映射
    lead_sheet, segment_beats, segment_beats_times = _format_lead_sheet(
        melody_logits,
        harmony_logits,
        beats_per_measure,
        beats,
        beats_times,
        segment_start_downbeat,
        segment_end_beat,
        total_num_tertiary,
        melody_threshold=melody_threshold,
        harmony_threshold=harmony_threshold,
    )

    # 创建 pulse 到 时间的映射函数
    pulse_to_time_fn = create_beat_to_time_fn(segment_beats, segment_beats_times)

    # 将lead_sheet转换成midi字节
    midi_bytes = lead_sheet.as_midi(pulse_to_time_fn=pulse_to_time_fn)

    # 存入磁盘
    output_midi_path = pathlib.Path(output_midi_path)
    output_midi_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_midi_path, "wb") as f:
        f.write(midi_bytes)

    logging.info(f"MIDI saved to {output_midi_path}")



def test_single_case(uid, 
                     checkpoint_path_melody, 
                     checkpoint_path_harmony, 
                     npz_dir, 
                     output_midi_dir, 
                     device="cuda:0"):
    """
    针对单个uid:
      1) 从 checkpoint_path_melody, checkpoint_path_harmony 加载模型
      2) 从 {npz_dir}/{uid}.npz 加载特征( chunks_features ) + beats/beats_times ...
      3) 做 forward, 得到 melody_logits, harmony_logits
      4) 保存到 .midi
    """

    cfg_mel_path = "/sheetsage/sheetsage/config_melody.json"
    with open(cfg_mel_path, "r") as f:
        d1 = json.load(f)
    cfg_mel = Config(d1)
    cfg_har_path = "/sheetsage/sheetsage/config_harmony.json"
    with open(cfg_har_path, "r") as f:
        d2 = json.load(f)
    cfg_har = Config(d2)

    # 1) 加载模型
    # model_mel = SheetsageLightningModule.load_from_checkpoint(checkpoint_path_melody, cfg=cfg_mel.d)
    # model_mel.eval()
    # model_har = SheetsageLightningModule.load_from_checkpoint(checkpoint_path_harmony, cfg=cfg_har.d)
    # model_har.eval()

    # inference model
    input_feats = InputFeats.JUKEBOX
    model_mel = _init_model(Task.MELODY, input_feats, Model.TRANSFORMER)
    model_har = _init_model(Task.HARMONY, input_feats, Model.TRANSFORMER)
    
    if torch.cuda.is_available() and "cuda" in device:
        model_mel.to(device)
        model_har.to(device)

    # 2) 读 npz
    npz_path = os.path.join(npz_dir, f"{uid}.npz")
    if not os.path.isfile(npz_path):
        raise FileNotFoundError(f"{npz_path} not found")

    data = np.load(npz_path, allow_pickle=True)
    if "chunks_features" not in data:
        raise KeyError("npz missing 'chunks_features'")

    chunks_features = data["chunks_features"]  # shape (N_chunks, T, feats_dim)
    # print("chunks_features", chunks_features)
    # beats_per_measure, beats, beats_times, ...
    beats_per_measure = data["beats_per_measure"]  # 例如4
    beats = data["beats"]                          # 形如 [0,1,2,...]
    beats_times = data["beats_times"]              # 与beats等长
    # 你可能还有 other fields

    # 3) 做 forward
    #    由于 chunks_features.shape=(N_chunks, T, feats_dim)，可以按 chunk 逐个推理
    #    并把logits拼起来
    all_melody_logits = []
    all_harmony_logits = []

    # 临时搞个 DataLoader 也行，或者干脆for循环
    # 这里示例用for循环直接 forward
    for c in range(chunks_features.shape[0]):
        feats_c = chunks_features[c]  # [T, feats_dim]
        feats_c = np.asarray(feats_c).astype(np.float32)
        feats_c = torch.from_numpy(feats_c).float().unsqueeze(1)  # => [T, 1, feats_dim]
        # src_len
        T_c = feats_c.shape[0]
        src_len = torch.tensor([T_c], dtype=torch.long)

        if torch.cuda.is_available() and "cuda" in device:
            feats_c = feats_c.to(device)
            src_len = src_len.to(device)

        with torch.no_grad():
            mel_logits_c = model_mel(feats_c, src_len)  # [T, 1, out_dim_mel]
            har_logits_c = model_har(feats_c, src_len)  # [T, 1, out_dim_har]

        # detach => to cpu => numpy
        mel_logits_c = mel_logits_c.cpu().numpy()[:,0,:]  # => shape (T, out_dim_mel)
        har_logits_c = har_logits_c.cpu().numpy()[:,0,:]  # => shape (T, out_dim_har)

        all_melody_logits.append(mel_logits_c)
        all_harmony_logits.append(har_logits_c)

    total_num_tertiary = sum([x.shape[0] for x in all_melody_logits])
    # 你也可以 cross-check => sum([c.shape[0] for c in chunks_features])
    # print('1',all_harmony_logits[0])
    # print('1.shape',len(all_harmony_logits[0]))
    all_melody_logits = np.concatenate(all_melody_logits, axis=0)
    print(all_melody_logits.shape)
    print('2',all_melody_logits[0])


    preds = np.argmax(all_melody_logits, axis=-1)
    print('preds',preds)
    print('shape', preds.shape)
    # print('2.shape',np.array(all_melody_logits).shape)
    # 4) 写成 .midi
    # 先假设 segment_start_downbeat=0, segment_end_beat = len(beats)-1
    segment_start_downbeat=0
    segment_end_beat=len(beats)-1

    out_midi_path = os.path.join(output_midi_dir, f"{uid}.mid")
    save_lead_sheet_as_midi(
        all_melody_logits,
        all_harmony_logits,
        beats_per_measure,
        beats,
        beats_times,
        segment_start_downbeat,
        segment_end_beat,
        total_num_tertiary,
        out_midi_path,
        melody_threshold=None,
        harmony_threshold=None
    )
    print(f"[INFO] {uid} => wrote {out_midi_path}")


if __name__=="__main__":
    # example usage
    checkpoint_path_harmony = "/home/dw3180/sheetsage_code/lightning_logs/version_test/checkpoints/Juke_harmony_epoch=epoch=1-val_loss=val_loss=0.5631.ckpt"
    checkpoint_path_melody= "/home/dw3180/sheetsage_code/lightning_logs/version_test/checkpoints/Mert_melody_epoch=epoch=1-val_loss=val_loss=0.5680.ckpt"
    test_uid = "BbWgMOYzolX"
    npz_dir = "/scratch/dw3180/sheetsage_project/output/preprocessed_output_refined/train"
    output_midi_dir = "/scratch/dw3180/sheetsage_project/output/midi_output"

    test_single_case(
        uid=test_uid,
        checkpoint_path_melody=checkpoint_path_melody,
        checkpoint_path_harmony=checkpoint_path_harmony,
        npz_dir=npz_dir,
        output_midi_dir=output_midi_dir,
        device="cuda:0"
    )
