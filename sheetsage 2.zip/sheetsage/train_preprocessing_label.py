import os
import gzip
import json
import numpy as np

###############################################
# 1) 定义 Interval -> 家族 映射 + 8大家族
###############################################
# 仅示例，你应根据实际数据增减
INTERVALS_TO_FAMILY = {
    (4, 3): "",       # major triad
    (3, 4): "m",      # minor triad
    (4, 3, 3): "7",   # dom7
    (3, 4, 3): "m7",
    (4, 3, 4): "maj7",
    (5, 2): "sus",    # 可能只表示三和弦
    (3, 3): "dim",
    (4, 4): "aug",
    # 如果有更多，比如 (3,3,3)->dim7 或 (3,3,4)->m7b5 等不在原8 family里面，就可以统一视作 UNK
    # ... 
}
# 八大家族
_HARMONY_FAMILIES = ["", "m", "m7", "7", "maj7", "sus", "dim", "aug"]
# 由此 12 (根音) × 8 (家族) = 96，再 +1 表示 <UNK>=0

def chord_event_to_label(chord_evt):
    """
    将一个和声事件映射为 [0..96] 间的整数标签。
    0 表示 <UNK>； 1..96 => root*8 + family_idx + 1
    忽略 inversion.
    chord_evt: {
      "onset": float, "offset": float,
      "root_pitch_class": int (0..11),
      "root_position_intervals": List[int],
      "inversion": int (可有可无, 忽略),
      ...
    }
    """
    root = chord_evt["root_pitch_class"]
    intervals = tuple(chord_evt["root_position_intervals"])  # e.g. (4,3) (3,4,3)...

    # 1) 根据 intervals 找到家族
    if intervals not in INTERVALS_TO_FAMILY:
        # 不在八大家族列表 => label=0
        return 0
    fam_name = INTERVALS_TO_FAMILY[intervals]
    if fam_name not in _HARMONY_FAMILIES:
        # 虽在INTERVALS_TO_FAMILY里，但不在 8 families => 仍记为UNK
        return 0

    fam_idx = _HARMONY_FAMILIES.index(fam_name)
    # 2) label = root*8 + fam_idx + 1
    label_id = root * len(_HARMONY_FAMILIES) + fam_idx + 1
    if label_id > 96:
        # 理论上不会
        return 0
    return label_id


def offline_label(uid, npz_in, melody_events, harmony_events, out_dir):
    """
    从 npz_in 中读取:
      - chunks_features (形如 (N_chunks,) 的 object数组 or (N_chunks,T_i,feats_dim))
      - chunks_tertiaries (与 features 对应，每帧的绝对时间)
    然后对齐 melody_events, 为每帧生成一个标签ID, 存到 "chunks_labels" 字段并写到 out_dir/<uid>.npz
    """

    data = np.load(npz_in, allow_pickle=True)

    if "chunks_features" not in data or "chunks_tertiaries" not in data:
        print(f"[WARN] {npz_in} 缺少 chunks_features 或 chunks_tertiaries，跳过。")
        return

    chunked_features = data["chunks_features"]    # object array or shape (N_chunks,T,feats_dim)
    chunked_tertiaries = data["chunks_tertiaries"]# object array or shape (N_chunks,T)
    tertiaries_times = data["tertiaries_times"]

    # 为了统一处理，这里把 chunked_features / chunked_tertiaries 都当 object array
    # 如果实际是 (N_chunks,T,feats_dim)，可以改写成 for i in range(N_chunks): feats_i = chunked_features[i, ...]
    # 这里示例: shape=(N_chunks,) => chunked_features[i] shape=(T_i, feats_dim)
    # 同样 chunked_tertiaries[i] shape=(T_i,)
    N_chunks = len(chunked_features)

    # 我们先准备一个列表, 存每个 chunk 的标签
    chunked_labels_list = []

    for i in range(N_chunks):
        feats_i = chunked_features[i]          # [T_i, feats_dim]
        chunked_tertiary = chunked_tertiaries[i]    # 来到对应的chunk帧
        times_i = tertiaries_times[chunked_tertiary][:-1]        # [T_i], 每帧绝对时间(秒),由于t_i帧覆盖的区间是 [t_i, t_{i+1}),所以会多一帧
        T_i = feats_i.shape[0]
        assert T_i == times_i.shape[0], "帧数不匹配!"

        labels_i = np.zeros((T_i,), dtype=np.int64)  # 默认全是0(无音)

        # 遍历该 chunk 的每一帧
        for f in range(T_i):
            frame_time = times_i[f]  # 这帧的绝对秒
            # 在 melody_events 找它对应的事件
            for note in melody_events:
                onset = note["onset"]
                offset= note["offset"]
                # 判断 frame_time 是否落在 [onset, offset)
                if onset <= frame_time < offset:
                    pc = note["pitch_class"]
                    octave = note["octave"]
                    label_id = pc + 12*(octave + 1)  # 例: 把音高映射成 int
                    labels_i[f] = label_id
                    break
                # 否则就保持默认0 = 无音
            # # 找到 harmony_events 中 onset<=frame_time<offset
            # for chord_evt in harmony_events:
            #     if chord_evt["onset"] <= frame_time < chord_evt["offset"]:
            #         label_id = chord_event_to_label(chord_evt)
            #         labels_i[f] = label_id
            #         break
            # # 如果没有 chord_evt 覆盖 => 保持0

        chunked_labels_list.append(labels_i)

    # 把 labels 组合成对应形状
    # 如果各 chunk 的 T_i 一样，可以直接 stack => [N_chunks, T_i]
    # 否则就只能存成 object array
    same_shape = all(chunked_labels_list[0].shape[0] == lbls.shape[0] for lbls in chunked_labels_list)
    if same_shape:
        chunked_labels = np.stack(chunked_labels_list, axis=0)
    else:
        chunked_labels = np.array(chunked_labels_list, dtype=object)

    # 把新的字段 "chunks_labels" 存进 data 并写到 out_dir
    new_data = dict(data)
    # new_data["chunks_labels"] = chunked_labels
    new_data["chunks_labels_harmony"] = chunked_labels

    os.makedirs(out_dir, exist_ok=True)
    outpath = os.path.join(out_dir, f"{uid}.npz")
    np.savez(outpath, **new_data)
    print(f"[offline_label_harmony] {uid} => {outpath} 处理完成。")


def main(hooktheory_json_gz, npz_dir, out_dir):
    """
    1. 读取 hooktheory_json_gz (里面包含 {uid: {"melody": [...], ...}, ...})
    2. 遍历 npz_dir 下所有 npz 文件
    3. 用文件名 uid 在 all_json 里找 ground truth (melody)
    4. 拿 tertiaries_times 和 chunks 送给 some_offline_preprocess(...)
    5. 存到 out_dir 目录
    """

    # 1) 读取 ground truth
    with gzip.open(hooktheory_json_gz, 'rt', encoding='utf-8') as f:
        all_json = json.load(f)  # dict, key=uid, val={"melody": [...], ...}

    # 若 out_dir 不存在，先创建
    os.makedirs(out_dir, exist_ok=True)

    # 2) 遍历 npz_dir 下所有 .npz
    for fn in os.listdir(npz_dir):
        if not fn.endswith(".npz"):
            continue

        uid = fn[:-4]  # 去掉 ".npz"
        npz_path = os.path.join(npz_dir, fn)


        # 3) 从 all_json 中取出 melody events
        melody_dict = all_json[uid]  # {"melody": [...], ...}
        melody_events = melody_dict['annotations']["melody"]
        if not melody_events:
            print(f"[WARN] uid={uid} has no 'melody', skip.")
            continue
        harmony_dict = all_json[uid]
        harmony_events = harmony_dict['annotations']["harmony"]
        if not harmony_events:
            print(f"[WARN] uid={uid} has no 'harmony', skip.")
            continue


        # offline_label(
        #     uid=uid,
        #     npz_in=npz_path,
        #     melody_events=melody_events,
        #     out_dir=out_dir
        # )
        offline_label(
            uid=uid,
            npz_in=npz_path,
            melody_events=melody_events,
            harmony_events=harmony_events,
            out_dir=out_dir
        )

        print(f"Processed and saved {uid} => {out_dir}")

    print("all done!")



def test_single_uid():
    # 请根据实际情况修改以下路径
    hooktheory_json_gz = "/home/dw3180/sheetsage_code/sheetsage/Hooktheory.json.gz"  # Hooktheory ground truth 数据（gzip压缩的 JSON）
    npz_dir = "/scratch/dw3180/sheetsage_project/output/preprocessed_output/valid"   # 存放原始 npz 文件的目录
    out_dir = "/scratch/dw3180/sheetsage_project/output/preprocessed_output/valid"   # 输出新增了 ground truth 的 npz 文件目录

    # 1. 加载 Hooktheory.json.gz 中的数据
    with gzip.open(hooktheory_json_gz, 'rt', encoding='utf-8') as f:
        hooktheory_data = json.load(f)

    # 2. 指定一个测试 uid
    uid = "KyvmrwbVgOW"  # 替换为你希望测试的 uid
    if uid not in hooktheory_data:
        print(f"UID {uid} 不在 Hooktheory 数据中")
        return

    # print(hooktheory_data[uid]['annotations']["melody"])

    melody_events = hooktheory_data[uid]['annotations']["melody"]
    if not melody_events:
        print(f"UID {uid} 没有 melody 数据")
        return
    harmony_events = hooktheory_data[uid]['annotations']["harmony"]
    if not harmony_events:
        print(f"UID {uid} 没有 harmony 数据")
        return

    # 3. 根据 uid 构造 npz 文件路径，并检查文件是否存在
    npz_path = os.path.join(npz_dir, f"{uid}.npz")
    if not os.path.isfile(npz_path):
        print(f"NPZ 文件 {npz_path} 不存在")
        return

    # 4. 设置 Jukebox 参数
    hop_length = 8       # 底层 hop_length
    sample_rate = 44100  # 采样率

    # 5. 调用 offline_label 对该 uid 进行处理
    # offline_label(
    #     uid=uid,
    #     npz_in=npz_path,
    #     melody_events=melody_events,
    #     out_dir=out_dir
    # )
    offline_label(
        uid=uid,
        npz_in=npz_path,
        melody_events=melody_events,
        harmony_events=harmony_events,
        out_dir=out_dir
    )

if __name__ == '__main__':
    # 你可以在这儿根据需求来调用:
    # test_single_uid()  # 只处理一个uid
    # 或者写 argparse 从命令行指定:
    import argparse
    parser = argparse.ArgumentParser(description="Offline labeling for Hooktheory NPZ files.")
    parser.add_argument("--hooktheory_json_gz", type=str, required=True, help="Path to Hooktheory.json.gz")
    parser.add_argument("--npz_dir", type=str, required=True, help="Input NPZ directory")
    parser.add_argument("--out_dir", type=str, required=True, help="Output directory for new NPZ files with chunks_labels")
    parser.add_argument("--test_only", action="store_true", help="If set, call test_single_uid() instead of main")
    args = parser.parse_args()

    if args.test_only:
        test_single_uid()
    else:
        main(args.hooktheory_json_gz, args.npz_dir, args.out_dir)
