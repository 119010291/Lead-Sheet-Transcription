import gzip
import json
import logging
import math

def split_train_set_into_dicts(hooktheory_json_gz, num_parts=10):
    """
    读取 Hooktheory.json.gz 并筛选出 train_set,
    然后将 train_set 的条目分成 num_parts 份，每份写到一个 JSON 文件中。

    这样每个 part 都是一个 dict，包含 UID -> 其完整 v (annotations, alignment, etc.)
    """

    # 读取并筛选
    with gzip.open(hooktheory_json_gz, "rt", encoding="utf-8") as f:
        dataset = json.load(f)
    logging.info(f"Total examples in Hooktheory: {len(dataset)}")

    train_set = {
        k: v for k, v in dataset.items()
        if v["split"] == "TRAIN"
        and "AUDIO_AVAILABLE" in v["tags"]
        and "MELODY" in v["tags"]
        and "TEMPO_CHANGES" not in v["tags"]
    }
    logging.info(f"Filtered train set size: {len(train_set)}")

    # 将 train_set 转成一个 list of (k, v)
    train_items = list(train_set.items())
    n = len(train_items)

    # 分块大小（向上取整）
    chunk_size = math.ceil(n / num_parts)

    for i in range(num_parts):
        start = i * chunk_size
        end = min(start + chunk_size, n)
        part_items = train_items[start:end]
        # 把这部分转换回 dict
        part_dict = dict(part_items)

        # 写到 JSON 文件
        out_file = f"train_set_part{i}.json"
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(part_dict, f)
        logging.info(f"Wrote {len(part_dict)} entries to {out_file}")

if __name__ == "__main__":
    import sys
    import logging

    logging.basicConfig(level=logging.INFO)

    if len(sys.argv) < 2:
        print("Usage: python split_train_set_dict.py <Hooktheory.json.gz> [num_parts]")
        sys.exit(1)

    hooktheory_json_gz = sys.argv[1]

    split_train_set_into_dicts(hooktheory_json_gz, num_parts=10)
