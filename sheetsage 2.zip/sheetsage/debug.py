import numpy as np

# # 加载 .npz 文件
data = np.load("/scratch/dw3180/sheetsage_project/output/preprocessed_output_refined/train/BbWgMOYzolX.npz", allow_pickle=True)
# data = np.load("/scratch/dw3180/sheetsage_project/output/preprocessed_output/train/-Wegl_nKmrY.npz", allow_pickle=True)
# data = np.load("/scratch/dw3180/sheetsage_project/output/preprocessed_output_refined/train/d_gw--JeoGV.npz", allow_pickle=True) # melody含负数
data2 = np.load("/scratch/dw3180/sheetsage_project/output/preprocessed_output_refined/valid/-kwxAbqXoKG.npz", allow_pickle=True)
data3 = np.load("/scratch/dw3180/sheetsage_project/output/preprocessed_output_refined/valid/nYAg-_Eaole.npz", allow_pickle=True)
data4 = np.load("/scratch/dw3180/sheetsage_project/output/preprocessed_output/test/-kwxAMkXxKG.npz", allow_pickle=True)
data5 = np.load("/scratch/dw3180/sheetsage_project/output/preprocessed_output/test/JkmZYkv-oqn.npz", allow_pickle=True)
# data = np.load("/scratch/dw3180/sheetsage_project/output/preprocessed_output/train/-Wegl__JmrY.npz", allow_pickle=True)

# # print(data["chunks_features"].shape)
# # print(data["chunks_features"][0].dtype)  # 打印数据类型
# # print(data["chunks_features"][0].shape)  # 打印形状

# 打印所有字段的信息
# for key in data.files:
#     print(f"Key: {key}")
#     print(f"  Data type: {data[key].dtype}")
#     print(f"  Shape: {data[key].shape}")
#     print(f'data:{data[key]}')
# print(" ")
# for key in data2.files:
#     print(f"Key: {key}")
#     print(f"  Data type: {data5[key].dtype}")
#     print(f"  Shape: {data5[key].shape}")
#     # print(f"  Sample data: {data[key][:2]}\n")  # 打印前两个样本（如果有） 
# print(data["chunks_features"][0].shape)
# # print(data["chunks_tertiaries"])
# print(data["chunks_features_mert"][0].shape)
print(data["chunks_labels"])
# # print(data2["chunks_tertiaries"])
# # print(len(data["chunks_features"]))
# # print(len(data2["chunks_features"]))
# # chunked_tertiaries = data2["chunks_tertiaries"][0]# object array or shape (N_chunks,T)
# # tertiaries_times = data2["tertiaries_times"]
# print(data["chunks_labels"][0].shape)
# # print(tertiaries_times[chunked_tertiaries])
# import sklearn